package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcelDataIntegration;

public class ProjectSpecificMethods extends AbstractTestNGCucumberTests{
	
	public String fileName;
	
	private static final ThreadLocal<RemoteWebDriver> cDriver = new ThreadLocal<RemoteWebDriver>();
     
	public void setDriver(String browser) {
		if (browser.equalsIgnoreCase("chrome")) {
			cDriver.set(new ChromeDriver());
		}
		else if (browser.equalsIgnoreCase("edge")) {
			cDriver.set(new EdgeDriver());
		}
		else if (browser.equalsIgnoreCase("firefox")) {
			cDriver.set(new FirefoxDriver());
		}
		

	}
	
	public RemoteWebDriver getDriver() {
		return cDriver.get();
		
	}
	
	@Parameters("browser")
	@BeforeMethod
	public void preCondition(String browser) {
		setDriver(browser); //initialization
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}

	
	@AfterMethod
	public void postCondition() {
       getDriver().close();

	}
	
	@DataProvider(parallel=true,indices=1)
	public String[][] sendData() throws IOException  {
		return ReadExcelDataIntegration.readExcel(fileName);

	}


}
