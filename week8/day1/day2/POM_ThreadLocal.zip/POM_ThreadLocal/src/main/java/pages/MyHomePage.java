package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.And;

public class MyHomePage extends ProjectSpecificMethods{

   @And("Click on Leads Link")
	public MyLeadsPage clickLeadsLink() {
	   getDriver().findElement(By.linkText("Leads")).click();
		return new MyLeadsPage();

	}
	
}
