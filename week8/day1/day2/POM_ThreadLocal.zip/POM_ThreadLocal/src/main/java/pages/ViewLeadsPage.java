package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Then;

public class ViewLeadsPage extends ProjectSpecificMethods{
	
	@Then("ViewLeadPage should be displayed as (.*)$")
	public ViewLeadsPage verifyLeads(String cName) {
		String text = getDriver().findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(cName)) {
			System.out.println("Lead created successfully");
		}
		else {
			System.out.println("Lead is not created");
		}
		return this;
		

	}

}
