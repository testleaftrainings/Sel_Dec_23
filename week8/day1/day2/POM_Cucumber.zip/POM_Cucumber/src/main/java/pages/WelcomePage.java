package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends ProjectSpecificMethods{
	
	
	
	@Then("HomePage should be displayed")
	public WelcomePage verifyLogin() {
		
		String text = driver.findElement(By.tagName("h2")).getText();
		if (text.contains("Welcome")) {
			System.out.println("Logged in Successfully");
		}
		else {
			System.out.println("Login is not successfull");
		}
		
		return this;

	}
	
	@When("Click on crmsfa link")
	public MyHomePage clickCRMSFALink() {
		driver.findElement(By.partialLinkText("CRM")).click();
		return new MyHomePage();
	}

}
