package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import utils.ReadExcelDataIntegration;

public class ProjectSpecificMethods {
	
	public ChromeDriver driver;
	public String fileName;

	@BeforeMethod
	public void preCondition() {
		driver=new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}

	
	@AfterMethod
	public void postCondition() {
       driver.close();

	}
	
	@DataProvider(indices=1)
	public String[][] sendData() throws IOException {
		return ReadExcelDataIntegration.readExcel(fileName);

	}

}
