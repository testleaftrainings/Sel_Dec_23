package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import config.ConfigurationManager;

public class LoginPage extends ProjectSpecificMethods{

	public LoginPage(ChromeDriver driver){
		this.driver=driver;
	}

	public LoginPage enterUsername(String uName) {
		driver.findElement(By.id("username")).sendKeys(ConfigurationManager.configuration().getUsername());
		return this;

	}

	public LoginPage enterPassword(String pWord) {
		driver.findElement(By.id("password")).sendKeys(ConfigurationManager.configuration().getPassword());
		return this;


	}

	public WelcomePage clickLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage(driver);

	}

}
