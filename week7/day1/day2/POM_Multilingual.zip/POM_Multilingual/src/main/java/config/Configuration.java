package config;

import org.aeonbits.owner.Config;

@Config.Sources("classpath:config.fr.properties")
public interface Configuration extends Config{
	
	@Key("timeout")
	int getTimeout();
	
	@Key("username")
	String getUsername();
	
	@Key("password")
	String getPassword();
	
	@Key("verifyLogin")
	String getVerifyLogin();
	
	@Key("leadslink")
	String getLeadsLink();
	
	@Key("createleadlink")
	String getCreateLeadLink();

}
