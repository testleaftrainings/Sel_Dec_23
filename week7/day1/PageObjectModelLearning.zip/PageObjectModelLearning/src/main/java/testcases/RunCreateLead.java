package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;


public class RunCreateLead extends ProjectSpecificMethods{
	
	
	@Test
	public void runLogin() {
		System.out.println("Test method: "+driver);
		
		
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.verifyLogin()
		.clickCRMSFALink();
		
		
		
	}

}
