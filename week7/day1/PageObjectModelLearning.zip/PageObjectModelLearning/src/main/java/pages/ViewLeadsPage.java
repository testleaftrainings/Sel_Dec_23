package pages;

import base.ProjectSpecificMethods;

public class ViewLeadsPage extends ProjectSpecificMethods{

}
