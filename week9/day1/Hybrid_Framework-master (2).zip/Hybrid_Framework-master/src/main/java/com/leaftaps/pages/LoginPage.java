package com.leaftaps.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethods {

	
	@Given("Enter the username as {string}")
	public LoginPage enterUserName(String unmae) {
		typeAndTab(locateElement(Locators.ID, "username"), unmae);
		reportStep("Entered the username successfully", "pass");
		return this;

	}

	@Given("Enter the password as {string}")
	public LoginPage enterPassword(String password) {
		typeAndTab(locateElement(Locators.ID, "password"), password);
		reportStep("Enterd the password successfully","pass");
		return this;
	}

	@When("Click on login button")
	public HomePage clickLogin() {
		click(locateElement(Locators.XPATH, "//input[@class='decorativeSubmit']"));
		reportStep("Clicked the login successfully","pass");

		return new HomePage();
	}

}
