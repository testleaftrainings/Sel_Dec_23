package com.framework.selenium.api.design;

public enum Locators {
	
	ID, XPATH, CLASS_NAME, NAME, CSS, LINK_TEXT, PARTIAL_LINKTEXT, TAGNAME

}
